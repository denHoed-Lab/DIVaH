# DIVaH
DIVaH - **D**anio rerio **I**dentification of **Va**riants by **H**aplotype

## Table of Contents  
- [What is DIVaH?](#what-is-divah)
- [Worflow](#worflow)
- [Input files](#input-files)
- [Output files](#output-files)
- [How to use it?](#how-to-use-it) 


## What is DIVaH?
DIVaH is a calling variant algorithm specifically designed for the alignment of short reads from next-generation sequencing data to a reference genome, initially developed for zebrafish genome but can be applied to other organisms as well. It runs in the R programming language and uses a heuristic approach to align reads to the reference genome, taking into account the diploid nature of the genome. DIVaH is able to accurately identify single nucleotide variations (SNVs) and small insertions and deletions (indels) and derives genotype calls for a diploid genome, providing valuable information on the genetic makeup of the individual or population being studied. This algorithm is robust, efficient, and able to handle large datasets, making it a valuable tool for genetic research.

## Worflow
The algorithm consists of 10 steps:
1. Reading input files
2. Extracting information from `Sequence_information.csv` (i.e., reference sequence, start position, and chromosome number). Extracting barcode from [BAM files](https://software.broadinstitute.org/software/igv/bam#:~:text=A%20BAM%20file%20(.,io%2Fhts%2Dspecs%2F.)) filename and reads;
3. Computing length of reference sequence; computing length of each read. If the difference between the two lengths ≥ 170 characters, the read is considered to be a product of sequencing error and therefore excluded;
4. Identifying unique reads; counting number of occurrences of each of theose unique reads, and ordering them in descending order;
5. Aligning each unique read to the reference sequence and constructing a CIGAR for each read. Removing sequences with CIGAR length ≥ 50 characters, considered to be a product of sequencing error.
![image](CIGAR_example.png)

7. Assigning the two reads with highest number of occurrences to be allele 1 (i.e., n_allele1) and allele 2 (i.e., n_allele2) respectively. 
8. Assigning hetero-/	homo-zygousity based on the following condition:  </br>
      homozygous:   `n_allele1 - n_allele2 ≥ n_allele1 * 0.75 == TRUE`  </br>
      heterozygous: `n_allele1 - n_allele2 ≥ n_allele1 * 0.75 == FALSE`  </br>
8. Generating summary table (`Complete_dataframe.csv` file)
9. Identifying the variants
10. Generating the `VEP1.csv` and the `VEP2.csv` files
 

## Input files
The algorithm takes as input: 
- [BAM files](https://software.broadinstitute.org/software/igv/bam#:~:text=A%20BAM%20file%20(.,io%2Fhts%2Dspecs%2F.)) outputted by [samtool](http://www.htslib.org/) with short reads sequences for individual larvae
- `Sequence_information.csv` file with 4 columns:
    - column 1: **Target** with the gene name (the same as in the BAM file name)
    - column 2: **Reference sequence** it corresponds to the sequence included between the primers (primers excluded)
    - column 3: **Chr** the chromosome number
    - column 4: **Start position** the position of the first nucleotide of the Reference sequence as proved by UCSC (for zebrafish use: GRCz11/danRer11)


#### How to build the Sequence_information.csv file
1. Visit the [UCSC Genome Browser](https://genome.ucsc.edu/) website and select the *Genome Browser* tool;
2. Select *Zebrafish assembly May 2017(GRCz11/denRer11)*;
3. Type in the name of the gene and select the NCBI RefSeq curated subset link;
4. Past the amplicon Reference sequence (included between the primers) :
    -  if the gene sequence in Ensembl is provided in the *forward* strand (i.e., "+") no additional changes are required;
    -  if the gene sequence in Ensembl is provided in the *reverse* strand (i.e., "-"), generate first the reverse-complement of the amplicon sequence (using tools such as [ApE](https://www.frontiersin.org/articles/10.3389/fbinf.2022.818619/full));
5. The [UCSC Genome Browser](https://genome.ucsc.edu/) will generate a table where the chromosome number and the starting position information can be accessed. Select the query with highest score and identity percentage.
</br>
NOTE: a  way to verify that the amplicon sequence provided to [UCSC Genome Browser](https://genome.ucsc.edu/) is on the right direction, is to check that the query in the output file is on the "+" strand.

For more details refer the the *FILE PREPARATION FOR NGS ANALYSIS PIPELINE.docx*.

## Output files
The algorithm outputs 3 files:
1. The `Complete_dataframe.csv` file with information provided for each individual sequenced. The file has 12 columns:
    - barcode specific for each individual 
    - gene name (as provided in Sequence_information.csv file)
    - chromosome number (as provided in Sequence_information.csv file)
    - reference sequence (as provided in Sequence_information.csv file)
    - position of teh first nucleotide (as provided in Sequence_information.csv file)
    - sequence of one allele (i.e., allele 1)
    - number of occurrences of the first allele
    - cigar relative to the first allele
    - sequence of the other allele (i.e., allele 2)
    - number of occurrences of the other allele
    - cigar relative to the other allele
    - whether the individual is assigend to be heterozyogous or homozygous
![image](Complete_DF_example.png)
    
2. The `VEP1.csv` file providing for each indidual sequence the list of variants generated in each amplicon for the first allele. The file has 6 columns:
    - barcode specific for each individual;
    - gene name (as provided in `Sequence_information.csv` file);
    - chromosome number (as provided in `Sequence_information.csv` file);
    - the position of the first nucleotide modified using the reference sequence as baseline;
    - the position of the last nucleotide modified using reference sequence as baseline;
    - the nature of the variant (reference/allele):
        - deletion (e.g., GATGGTG/-)
        - insertion (e.g., -/A)
        - substitution (e.g., C/G)
    - if no variant was present the column 4 and 5 contains missing values and the 6th column has "WT".
![image](VEP_example.png)

3. The `VEP2.csv` file providing for each indidual sequence the list of variants generated in each amplicon for the second allele, if the individual is considered heterozygous. The file has 6 columns as described for the `VEP1.csv` file.


## How to use it?
The script was last ran using R version 3.4.0

To run the tool:
- Install R packages: `Rsamtools`, `msa` available from [Bioconductor](https://bioconductor.org/) and `plyr` available from [CRAN](https://cran.r-project.org/web/packages/plyr/index.html) 
- Generate the input file `Sequence_information.csv`

Make the following modification to the script:
- Working directories:
   - line 312: set `on_server == TRUE` (if running script on server) or `FALSE` (if running script locally)
   - line 315 or 319: set `REFERENCE_WD` as directory to output folder
   - line 316 or 320: set `SEQUENCES_FOLDER` as directory to folder with BAM files

- Step 1:
   - lines 329 and 330: output filename for VEP1
   - lines 332 and 333: output filename for VEP2
   - lines 335 and 336: output filename for Complete dataframe
</br>
Run the script locally or on the server by running `Rscript DIVAh.R`.


## How to cyte us
