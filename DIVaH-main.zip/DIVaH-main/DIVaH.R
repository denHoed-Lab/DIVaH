######## Library to upload
source("https://bioconductor.org/biocLite.R")
biocLite("Rsamtools")

source("https://bioconductor.org/biocLite.R")
biocLite("msa")

library("Rsamtools") 
library("plyr")      
library("msa")

########### FUNCTIONS #################

##### Function to read sequences from bam file
ReadSequences = function(file, RefSequence){
  # Read sequences
  library("Rsamtools") 
  
  fileBam = scanBam(file)
  sequences = as.data.frame(fileBam)$seq
  
  if (length(sequences) > 0 ) {
    
    # Create a dataframe with sequences 
    sequences = as.data.frame(sequences) 
    lengthSequence = as.data.frame(fileBam)$qwidth
    lengthSequence = as.data.frame(lengthSequence)
    Sequence_Length = data.frame(sequences, lengthSequence) 
    
    # Remove short reads RefSequence = referenceSequence
    ShortReads = which(with(Sequence_Length, abs(Sequence_Length$lengthSequence - nchar(RefSequence)) >= 170 ))
    if (length(ShortReads) > 0) {
      Sequence_Length = Sequence_Length [-ShortReads, ] 
    }
    
  } else {
    Sequence_Length = as.data.frame(matrix(NA, ncol = 2, nrow = 1))
    colnames(Sequence_Length) = c( "sequences", "lengthSequence")
  }
  
  return(Sequence_Length)
}

###### Function to order duplicates
OrderDuplicates = function(SequenceLengthDataframe){
  
  if (nrow(SequenceLengthDataframe) == 1 && is.na(SequenceLengthDataframe$sequences)) {
    countDuplicates = as.data.frame(matrix(NA, ncol = 3, nrow = 1))
    colnames(countDuplicates) = c("Sequences", "Length", "Num of duplicates" )
  } else if (nrow(SequenceLengthDataframe) == 0){ 
    countDuplicates = as.data.frame(matrix(NA, ncol = 3, nrow = 1))
    colnames(countDuplicates) = c("Sequences", "Length", "Num of duplicates" )
  } else {
    countDuplicates = ddply(SequenceLengthDataframe, .(sequences, SequenceLengthDataframe[,2]), nrow)
    countDuplicates = countDuplicates[order(-countDuplicates$V1),,drop = FALSE]
    colnames(countDuplicates) = c("Sequences", "Length", "Num of duplicates" )
    d = sapply(countDuplicates, is.factor)
    countDuplicates[d] = lapply(countDuplicates[d], as.character)
  }
  return(countDuplicates)
}

#### Function to generate cigar 
cigarGenerator = function(RefSequence, String){
  cigar = c()
  
  library("msa")  
  aligseq = c(RefSequence,  String) #Store in a vector the sequences to align 
  AlignSeq = msa(DNAStringSet(aligseq), "Muscle", order = "input")
  AlignMatrix = as.matrix(AlignSeq)
  
  for (m in 2:nrow(AlignMatrix)) {    #2
    ref = AlignMatrix[1,]
    seq = AlignMatrix[m,]
    
    # Generate a cigar for each sequence
    for (nt in 1:length(ref)) {
      if (ref[nt] == "-") {
        cigar = append(cigar, "I")
      } else if (ref[nt] != "-" && seq[nt] == "-") {
        cigar = append(cigar, "D")
      } else if (ref[nt] ==  seq[nt]) {
        cigar = append(cigar, "M")
      } else {
        cigar = append(cigar, "S")
      }
    }
  }
  
  cigar = paste(cigar, collapse = "")   # Combine the output in a single list of characters
  cigarContracted = contract(cigar)
  new_cigar = CIGAR(cigarContracted)
  return(new_cigar)
}

##### Function to convert from string of letters to cigar
contract = function(string) {
  chars = strsplit(string, "")[[1]] # Split string from input into vector of chars
  # Auxiliar variables
  output = ''             # Output string
  lastChar = chars[1]     # Keeps track of last char seen
  counter = 1             # Count how many equal chars we have seen
  chars = chars[-1]       # Remove first element
  chars <- c(chars, '#')  # Add a fake element at the end so last one is compared
  
  for (char in chars) {  # Loop through each char
    # If it's equal to the last one, increment counter
    if (char == lastChar) {
      counter = counter + 1
      # Otherwise, it's a different char Paste it on output with counter and reset counter 
    } else {
      output = paste(output, toString(counter), lastChar, sep = "")
      lastChar = char
      counter = 1
    }
  }
  return(output)
}

##### Function to check if the length of cigar and of the allele are the same
match_length = function (cigar, allele){
  
  #Extract all characters from the cigar
  sub_cigar = gsub("[[:digit:]]","",cigar) 
  sub_cigar = unlist(strsplit(sub_cigar, ""))
  #Extract all digits from the cigar
  sub_numbers = unlist(strsplit(gsub("[^\\d]+", "-", cigar, perl=TRUE), "-")) 
  # Create a dataframe with value and numbers of the cigar
  df = data.frame(sub_cigar, sub_numbers)
  i = sapply(df, is.factor)          
  df[i] = lapply(df[i], as.character)
  # Remove D from the dataframe
  D_pos = df[ ! df$sub_cigar %in% "D", ]  
  # To verify that the length of the cigar and the length of the cigar (excluding "D") is the same
  if (is.na(allele)) {
    return(NA)
  } else if (sum(as.integer(D_pos$sub_numbers)) == nchar(allele)){
    return("Lengths match")
  } else {
    return("Lengths do not match")
  }
}

##### Function to substitute the != "M" in cigar (first and last position) with "N"
CIGAR = function(string){
  
  #Extract all characters from the cigar
  sub_cigar = gsub("[[:digit:]]","",string) 
  sub_cigar = unlist(strsplit(sub_cigar, "")) # "M" "S" "M" "I" "M" "S" "M" "I" "S" "M" "S" "M"
  
  if (length(sub_cigar >1)){
    #Extract all digits from the cigar
    sub_numbers = unlist(strsplit(gsub("[^\\d]+", "-", string, perl=TRUE), "-")) #"6"  "1"  "20" "11" "12" "1"  "41" "3"  "2"  "56" "1"  "13"
    
    # Create a dataframe with value and numbers of the cigar
    df = data.frame(sub_cigar, sub_numbers)
    i = sapply(df, is.factor)           # Identify if the dataframe has factors
    df[i] = lapply(df[i], as.character) # Convert all element of the dataframe to characters
    
    # Change first position of the cigar != "M" in "N"
    if (df[1,1] != "M"){
      df[1,1] = "N"
    }
    
    # Change last position of the cigar != "M" in "N"
    if (df[nrow(df), 1] != "M"){
      df[nrow(df), 1] = "N"
    }
    
    cgr_new = c()
    for (n in 1:nrow(df)){
      cgr_new = append(cgr_new, paste(df[n,2], df[n,1]))
    }
    cgr_new = gsub("\\s", "", paste(cgr_new, collapse='' ))
  } 
  return(cgr_new)
}

##### Function to calling variant 
VEP1 = function(dataframe1, all1, cgr) {
  sp = dataframe1$StartPos
  
  # Create dataframe with digits and characters from cigar, start and end position of variants (based on cigar)
  sub_cigar = gsub("[[:digit:]]","",cgr)
  sub_cigar = unlist(strsplit(sub_cigar, ""))
  sub_numbers = unlist(strsplit(gsub("[^\\d]+", "-", cgr, perl=TRUE), "-"))
  df = data.frame(sub_cigar, sub_numbers)
  i = sapply(df, is.factor)          
  df[i] = lapply(df[i], as.character)
  
  # Define start and end positions for allele
  start_pos_all = rep(NA, nrow(df))
  end_pos_all = rep(NA, nrow(df))
  df$start_pos_all = start_pos_all
  df$end_pos_all = end_pos_all  
  df_all = df [! (df$sub_cigar == "N"), ]
  df_all =  df_all [! ( df_all$sub_cigar == "D"), ]
  end_pos_all = cumsum(as.integer(df_all$sub_numbers))  
  all_pos = which(with(df, df$sub_cigar != "N" & df$sub_cigar != "D"))
  for (i in seq(1:length(all_pos))) {
    df$end_pos_all[all_pos [i] ] = end_pos_all [i]
    df$start_pos_all[all_pos [i] ] = end_pos_all [i] - as.integer(df$sub_numbers[all_pos [i] ]) + 1
  }
  
  # Define start and end positions for reference
  start_pos_ref = rep(NA, nrow(df))
  end_pos_ref = rep(NA, nrow(df))
  df$start_pos_ref = start_pos_ref
  df$end_pos_ref = end_pos_ref
  df_ref = df [! (df$sub_cigar == "I"), ]
  end_pos_ref = cumsum(as.integer(df_ref$sub_numbers)) 
  ref_pos = which(with(df, df$sub_cigar != "I"))
  for (n in 1:length(ref_pos)) {
    df$end_pos_ref[ref_pos [n] ] = end_pos_ref [n]
    df$start_pos_ref[ref_pos [n] ] = end_pos_ref [n] - as.integer(df$sub_numbers[ref_pos [n] ]) + 1
  }
  
  # Adjust reference positions in case there is I
  for (n in 1:nrow(df)){
    if (df$sub_cigar[n] == "I"){
      df$start_pos_ref[n] =  df$start_pos_ref[n + 1]
      df$end_pos_ref[n] = df$end_pos_ref[n + 1]
    }
  }
  
  df = df [! (df$sub_cigar == "N"), ] # removing N
  df = df [! (df$sub_cigar == "M"), ] # removing M
  
  # Column in the dataframe with the sequences
  
  if (nrow(df) > 0) {
    reference = c()
    allele = c()
    
    for (n in 1:nrow(df)) {
      if (df$sub_cigar[n] == "S") {
        ref = substr(dataframe1$ReferenceSequence, as.integer(df$start_pos_ref) [n], as.integer(df$end_pos_ref) [n] )
        all = substr(all1, as.integer(df$start_pos_all) [n], as.integer(df$end_pos_all) [n] )
      } else if (df$sub_cigar[n] == "I") {
        ref = "-"
        all = substr(all1, as.integer(df$start_pos_all) [n], as.integer(df$end_pos_all) [n] )
      } else if (df$sub_cigar[n] == "D") {
        ref = substr(dataframe1$ReferenceSequence, as.integer(df$start_pos_ref) [n], as.integer(df$end_pos_ref) [n] )
        all = "-"
      }
      reference = append(reference, ref)
      allele = append(allele, all)
    }
    
    df$ref = reference
    df$all = allele
    
    # Add column with vep format output
    vep_output = c()
    for (n in 1:nrow(df)){
      vep_output = append (vep_output, paste0(df$ref[n], "/" , df$all[n])) 
    }
    df$vep = vep_output
    
    # Add column with positions for reference
    start_vep = c()
    end_vep = c()
    for (n in 1:nrow(df)){
      # sp = starting position; ep = end position
      if (df$sub_cigar[n] == "S") {
        sp_ref = as.integer(sp) + as.integer(df$start_pos_ref) [n] - 1
        ep_ref = as.integer(sp) + as.integer(df$end_pos_ref) [n] - 1
      } else if (df$sub_cigar[n] == "I") {
        sp_ref = as.integer(sp) + as.integer(df$start_pos_ref) [n] - 1
        ep_ref = as.integer(sp) + as.integer(df$start_pos_ref) [n] - 2
      } else if (df$sub_cigar[n] == "D") {
        sp_ref = as.integer(sp) + as.integer(df$start_pos_ref) [n] - 1
        ep_ref = ep_ref = as.integer(sp) + as.integer(df$end_pos_ref) [n] - 1
      }
      start_vep = append (start_vep, sp_ref)
      end_vep = append(end_vep, ep_ref)
    }
    
    df$vep_start = start_vep
    df$vep_end = end_vep
    # Add column with barcode
    df$barcode = rep(dataframe1$Barcode, nrow(df)) 
    
    # Add column with targetsite
    df$targetsite = rep(dataframe1$Targetsite, nrow(df))
    
    # Add column with Chr
    df$Chr = rep(dataframe1$Chr, nrow(df))
    
    
    drops = c("sub_cigar", "sub_numbers", "start_pos_all", "start_pos_ref", "end_pos_ref", "ref", "all", "end_pos_all")
    VEP_OUTPUT  = df[, !(names(df) %in% drops)]
    
    VEP_OUTPUT = VEP_OUTPUT[, c(4, 5, 6, 2, 3, 1)]
    i_factor = sapply(VEP_OUTPUT, is.factor)          
    VEP_OUTPUT[i_factor] = lapply(VEP_OUTPUT[i_factor], as.character)
    
  } else {
    vep_start = NA
    vep_end  = NA
    barcode = dataframe1$Barcode
    targetsite = dataframe1$Targetsite
    Chr = dataframe1$Chr
    vep = "WT"
    VEP_OUTPUT = cbind.data.frame(barcode, targetsite, Chr, vep_start, vep_end, vep)
  }
  return(VEP_OUTPUT)
}


####### Working directory
on_server = TRUE # Set to FALSE if working locally

if (on_server) {
  REFERENCE_WD = "" # add directory to output folder
  SEQUENCES_FOLDER = "" # add directory to folder with BAM files
  OUTPUT_WD = ""  # add directory to output folder (same as  add directory to "REFERENCE_WD")
} else {
  REFERENCE_WD = "" # add directory to output folder
  SEQUENCES_FOLDER = "" # add directory to folder with BAM files
  OUTPUT_WD = "" # add directory to output folder (same as  add directory to "REFERENCE_WD")
  
}


####################### STEP 1 ##############################
##### Read the file with reference sequences
setwd(OUTPUT_WD)
file.create("VEP1_round8_pool1_divah.csv") # replace with your output filename
output_file1 = file("VEP1_round8_pool1_divah.csv", "w") # replace with your output filename

file.create("VEP2_round8_pool1_divah.csv") # replace with your output filename
output_file2 = file("VEP2_round8_pool1_divah.csv", "w") # replace with your output filename

file.create("Complete_dataframe_round8_pool1_divah.csv") # replace with your output filename
output_dataframe = file("Complete_dataframe_round8_pool1_divah.csv", "w") # replace with your output filename

setwd(REFERENCE_WD)
referenceFile = read.csv("Sequence_information.csv", header = TRUE, sep = ";")
colnames(referenceFile) = c("Target", "Reference sequence", "Chr", "Start_position")
targetList = c()
for (n in seq(1: dim(referenceFile[1])[1])){
  targetList = append(targetList, as.character(referenceFile[n,1]))
}

####################### STEP 2 ##############################
##### Read the files to get the reads for the desired target
# Select only the files that end with out.bam
setwd(SEQUENCES_FOLDER)
filenames = list.files(path = SEQUENCES_FOLDER, 
                       pattern="\\.out\\.bam", full.names = TRUE)

filenames = as.data.frame(filenames) 

# Create empty list to store the right names of the files
listfiles = list()                   
for (n in seq(1:dim(filenames)[1])) {
  file = as.character(filenames[n,1])
  file = gsub(paste0(SEQUENCES_FOLDER, "/") ,"", file) # Substitute the first part of the file 
  # name with nothing and replace the new value 
  listfiles = rbind(listfiles, file)
}

# Convert listfiles from matrix to characters
listfiles = as.character(listfiles) 


####################### STEP 3 ##############################
##### Analyse 

for (index in 1:length(listfiles)) {
  n = listfiles[index]
  print(paste("Running", index, "out of", length(listfiles), ":", n))
  
  barcodeList = c()
  targetsiteList = c()
  allele1List = c()
  allele1reads= c()
  allele2List = c()
  allele2reads= c()
  cigarList1 = c()
  cigarList2 =c()
  
  # Data for barcode and targetsite
 
   barcode = unlist(strsplit(n, "[_]"))[2]
   barcodeList = append(barcodeList, barcode)
   targetsite = unlist(strsplit(n, "[_]"))[4]
   targetsiteList = append(targetsiteList, targetsite)
   targetName = unlist(strsplit(n, "[_]"))[4]
    

  referenceSequence = as.character(referenceFile[(which(referenceFile$Target == targetName)), 2])
  read_sequences = ReadSequences(n, referenceSequence) # output is dataframe with sequences and length
  orderDuplicates = OrderDuplicates(read_sequences)
  
  #Combine cigar and orderDuplicates
  cigarList = c()
  for (n in orderDuplicates$Sequences){
    if (is.na(n) == TRUE){
      cigarList = append(cigarList, NA)
    } else {
      cigarList = append(cigarList, cigarGenerator(referenceSequence, n ))
    }
  }
  
  # Append cigar to the list of sequences ordered
  orderDuplicates$Cigar = cigarList
  
  # # Remove the sequences with a cigar length > 50
  # long_cigar = which(with(orderDuplicates, nchar(orderDuplicates$Cigar) >= 50)) 
  # if (length(long_cigar) != 0) {
  #   orderDuplicates = orderDuplicates[-long_cigar, ]
  # }
  # 
  
  # Assign value to Allele1, Allele2, Cigar1, Cigar2, Reads_Allele1, Reads_Allele2
  if (nrow(orderDuplicates) >=  2) { 
    Allele1 = orderDuplicates$Sequences[1]
    Reads_Allele1 = orderDuplicates$`Num of duplicates`[1]
    Cigar1 = orderDuplicates$Cigar[1]
    Allele2 = orderDuplicates$Sequences[2]
    Reads_Allele2 = orderDuplicates$`Num of duplicates`[2]
    Cigar2 = orderDuplicates$Cigar[2]
    
    allele1List = append(allele1List, Allele1)
    allele1reads= append(allele1reads, Reads_Allele1)
    allele2List = append(allele2List, Allele2)
    allele2reads = append(allele2reads, Reads_Allele2)
    cigarList1 = append(cigarList1, Cigar1)
    cigarList2 =append(cigarList2, Cigar2)
    
  } else if (nrow(orderDuplicates) ==  1) {
    Allele1 = orderDuplicates$Sequences[1]
    Reads_Allele1 = orderDuplicates$`Num of duplicates`[1]
    Cigar1 = orderDuplicates$Cigar[1]
    Allele2 = NA
    Reads_Allele2 = NA
    Cigar2 = NA
    
    allele1List = append(allele1List, Allele1)
    allele1reads= append(allele1reads, Reads_Allele1)
    allele2List = append(allele2List, Allele2)
    allele2reads = append(allele2reads, Reads_Allele2)
    cigarList1 = append(cigarList1, Cigar1)
    cigarList2 =append(cigarList2, Cigar2)
    
  } else if (nrow(orderDuplicates) ==  0){
    Allele1 = NA
    Reads_Allele1 = NA
    Cigar1 = NA
    Allele2 = NA
    Reads_Allele2 = NA
    Cigar2 = NA
    
    allele1List = append(allele1List, Allele1)
    allele1reads= append(allele1reads, Reads_Allele1)
    allele2List = append(allele2List, Allele2)
    allele2reads = append(allele2reads, Reads_Allele2)
    cigarList1 = append(cigarList1, Cigar1)
    cigarList2 =append(cigarList2, Cigar2)  
  }
  
  # Add vector for reference sequence, Chr number and starting position
  refseqList = c()
  Chr = c()
  StartPosition = c()
  for (n in targetsiteList){
    RefSeq = as.character(referenceFile[(which(referenceFile$Target == n)), 2])
    chr = referenceFile$Chr[referenceFile$Target == n ]
    posit = referenceFile$Start_position [referenceFile$Target == n ]
    refseqList = append(refseqList, RefSeq)
    Chr = append(Chr, chr)
    StartPosition = append(StartPosition,  posit)
  }
  
  dataframe1 = cbind(barcodeList, targetsiteList, Chr, refseqList, StartPosition, allele1List, allele1reads, cigarList1, allele2List, allele2reads, cigarList2) 
  dataframe1 = as.data.frame(dataframe1)
  colnames(dataframe1) = c("Barcode", "Targetsite", "Chr", "ReferenceSequence", "StartPos", "Allele1", "ReadsAllele1", "Cigar1", "Allele2", "ReadsAllele2", "Cigar2")
  
  # Remove rows with allele1 = NA
  if (is.na(dataframe1$Allele1) == TRUE) {
    NApos = which(with(dataframe1, is.na(dataframe1$Allele1)))
    dataframe1 = dataframe1[-NApos, ]
    
  } else {
    
    # Change factors in characters
    id = sapply(dataframe1, is.factor)
    dataframe1[id] <- lapply(dataframe1[id], as.character)
    
    # Remove rows with ReadsAllele1 < 5
    if (as.integer(dataframe1$ReadsAllele1) < 5) {
      fewReads = which(with(dataframe1, as.integer(dataframe1$ReadsAllele1) < 5))
      dataframe1 = dataframe1[-fewReads, ]
    } else {
      # Check for homo/heterozygous
      homo_het = c()
      for (n in 1:dim(dataframe1)[1]){
        # If digits available for both reads allele1 and allele2
        if (is.na(dataframe1$ReadsAllele2 [n]) == FALSE){
          x = as.integer(dataframe1$ReadsAllele1[n])
          y = as.integer(dataframe1$ReadsAllele2[n])
          
          if ( x-y >= x * 0.75){
            homo_het = append(homo_het, "homozygous")
          } else{
            homo_het = append(homo_het, "heterozygous")
          }
          # If digits available only for allele1
        } else {
          homo_het = append(homo_het, "homozygous")
        }
      }
      dataframe1$Homo_Het = homo_het
    }
  }
  
  # Set allele2 to missing if fish is homozygous
  if (nrow(dataframe1) == 0) {
    print(paste("Skipping file (number of reads less than 5): ", listfiles[index]))
    next
  }
  
  if (dataframe1$Homo_Het == "homozygous") {
    dataframe1$Allele2[n] = NA
    dataframe1$ReadsAllele2[n] = NA
    dataframe1$Cigar2[n] = NA
  }
  
  #  # Set "Homozygous" if only allele1 available
  if (is.na(dataframe1$Allele2) == TRUE && dataframe1$Homo_Het == "heterzygous" ) {
    dataframe1$Homo_Het[n] = "homozygous"
  }
  
  write.table(dataframe1, file = output_dataframe, sep = ",", col.names = F, row.names= F, append = T)
  flush(output_dataframe)
  #   ####################### STEP 5 ##############################
  #   ##### Variant calling
  
  all1 = dataframe1$Allele1
  cgr =  dataframe1$Cigar1
  
  name_df = VEP1(dataframe1, all1, cgr)
  
  if (class(name_df) == "data.frame" && empty(name_df) == FALSE) { 
    write.table(name_df, file = output_file1, sep = ",", col.names = F, row.names= F, append = T)
    flush(output_file1)
  }
  
  all2 = dataframe1$Allele2
  cgr2 =  dataframe1$Cigar2
  if (is.na(all2) == FALSE && is.na(cgr2) == FALSE) {
    name_df2 = VEP1(dataframe1, all2, cgr2)
    if (class(name_df2) == "data.frame" && empty(name_df2) == FALSE) { 
      write.table(name_df2, file = output_file2, sep = ",", col.names = F, row.names= F, append = T)
      flush(output_file2)
    }
  }
}

